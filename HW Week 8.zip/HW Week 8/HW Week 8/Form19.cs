﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace HW_Week_8
{
    public partial class Form19 : Form
    {
        public Form19()
        {
            InitializeComponent();
        }
        public static Button[,] kumpulanbuttonbuatkursi = new Button[10, 10];
        List<Button> buttonkursi = new List<Button>();
        int kesamping = 30;
        int kebawah = 60;
        int count = 0;
        private void button_click(object sender, EventArgs e)
        {
            var buttonclick = sender as Button;
            if (buttonclick.BackColor == Color.Red)
            {
                MessageBox.Show("Sudah ada orangnya kak");
            }
            if (buttonclick.BackColor == Color.White)
            {
                buttonclick.BackColor = Color.Green;
                Form1.kursihijau18.Add(buttonclick.Tag.ToString());
            }
        }
        private void Form19_Load(object sender, EventArgs e)
        {
            if (Form1.angka18 == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        kumpulanbuttonbuatkursi[i, j] = new Button();
                        kumpulanbuttonbuatkursi[i, j].Size = new Size(30, 30);
                        kumpulanbuttonbuatkursi[i, j].Location = new Point(kesamping, kebawah);
                        kumpulanbuttonbuatkursi[i, j].Tag = i + "," + j + ",belum tersedia";
                        kumpulanbuttonbuatkursi[i, j].BackColor = Color.White;
                        kumpulanbuttonbuatkursi[i, j].Click += button_click;
                        buttonkursi.Add(kumpulanbuttonbuatkursi[i, j]);
                        this.Controls.Add(kumpulanbuttonbuatkursi[i, j]);
                        kesamping += 30;


                    }
                    kebawah += 60;
                    kesamping = 30;
                }
                Random rnd = new Random();
                int hasilrandom = rnd.Next(0, 70); //buat dapatin hasil angka random, hasil tersebut dibuat berapa jumlah okupansi bioskop yang sudah full
                for (int i = 0; i < hasilrandom; i++)
                {
                    int kursikepilih = rnd.Next(0, 100);//buat ngerandom kursi ke berapa yang bakal terisi
                    foreach (Button b in buttonkursi)
                    {
                        if (count == kursikepilih)
                        {

                            string checkbelumtersedia = b.Tag.ToString().Split(',')[2]; //hasilnya harus belum tersedia
                            if (checkbelumtersedia == "belum tersedia")
                            {
                                Form1.kursimerah18.Add(count);//buat masukinlist simpan kursi merah ada di urutan berapa
                                b.BackColor = Color.Red;
                                b.Tag = b.Tag.ToString().Split(',')[0] + "," + b.Tag.ToString().Split(',')[1] + ",sudah tersedia";
                            }
                        }
                        count++;


                    }
                    count = 0;
                }
            }
            if (Form1.angka18 > 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        kumpulanbuttonbuatkursi[i, j] = new Button();
                        kumpulanbuttonbuatkursi[i, j].Size = new Size(30, 30);
                        kumpulanbuttonbuatkursi[i, j].Location = new Point(kesamping, kebawah);
                        kumpulanbuttonbuatkursi[i, j].Tag = i + "," + j + ",belum tersedia";
                        kumpulanbuttonbuatkursi[i, j].BackColor = Color.White;
                        buttonkursi.Add(kumpulanbuttonbuatkursi[i, j]);
                        kumpulanbuttonbuatkursi[i, j].Click += button_click;
                        this.Controls.Add(kumpulanbuttonbuatkursi[i, j]);
                        kesamping += 30;


                    }
                    kebawah += 60;
                    kesamping = 30;
                }
                //dari line 75-92 bikin base code buat buttonnya
                int count1 = 0; //count 1 buat bantu nyari y
                foreach (int y in Form1.kursimerah18.ToList()) //y itu kursi keberapa yang merah
                {
                    foreach (Button b in kumpulanbuttonbuatkursi)
                    {
                        if (y == count1)// buat nyari button urutan ke y
                        {
                            b.BackColor = Color.Red;
                            b.Tag = b.Tag.ToString().Split(',')[0] + "," + b.Tag.ToString().Split(',')[1] + ",sudah tersedia";
                        }
                        count1++;//biarin nambah teros sampe ketemu y tersebut
                    }
                    count1 = 0; //di 0 in buat nyari y berikutnya

                }
                foreach (string n in Form1.kursihijau18.ToList()) //n itu kursi ke berapa yang hijau
                {
                    foreach (Button b in kumpulanbuttonbuatkursi) // buat nyari button n itu
                    {
                        if (n == b.Tag.ToString())//kalo tagnya sama ya itu buttonnya
                        {
                            b.BackColor = Color.Green;
                        }
                    }
                }
            }

            Form1.angka18++;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (Button button in buttonkursi)
            {
                if (button.BackColor == Color.Green)
                {
                    Form1.kursihijau18.Remove(button.Tag.ToString());
                    button.BackColor = Color.White;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
