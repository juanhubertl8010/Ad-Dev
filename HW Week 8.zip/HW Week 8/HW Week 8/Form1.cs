﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW_Week_8
{
    public partial class Form1 : Form
    {
        public static int angka1 = 0;
        public static List<int> kursimerah1 = new List<int>();
        public static List<string> kursihijau1 = new List<string>();
        /// Form2
        /// 
        /// </summary>
       public static int angka2 = 0;
        public static List<int> kursimerah2 = new List<int>();
        public static List<string> kursihijau2 = new List<string>();
        /// Form3
        /// 
        /// </summary>
        public static int angka3 = 0;
        public static List<int> kursimerah3 = new List<int>();
        public static List<string> kursihijau3 = new List<string>();
        /// Form4
        /// 
        /// </summary>
              public static int angka4 = 0;
        public static List<int> kursimerah4 = new List<int>();
        public static List<string> kursihijau4 = new List<string>();
        /// Form 5
        /// 
        /// </summary>
        public static int angka5 = 0;
        public static List<int> kursimerah5 = new List<int>();
        public static List<string> kursihijau5 = new List<string>();
        /// Form 6
        /// 
        /// </summary>
       public static int angka6 = 0;
        public static List<int> kursimerah6 = new List<int>();
        public static List<string> kursihijau6 = new List<string>();
        /// Form7
        /// 
        /// </summary>
             public static int angka7 = 0;
        public static List<int> kursimerah7 = new List<int>();
        public static List<string> kursihijau7 = new List<string>();
        /// Form8
        /// 
        public static int angka8 = 0;
        public static List<int> kursimerah8 = new List<int>();
        public static List<string> kursihijau8 = new List<string>();
        /// Form9
        /// 
        /// </summary>
        public static int angka9 = 0;
        public static List<int> kursimerah9 = new List<int>();
        public static List<string> kursihijau9 = new List<string>();
        /// Form 10
        /// 
        /// </summary>
        public static int angka10 = 0;
        public static List<int> kursimerah10 = new List<int>();
        public static List<string> kursihijau10 = new List<string>();
        /// Form11
        /// 
        /// </summary>
           public static int angka11 = 0;
        public static List<int> kursimerah11 = new List<int>();
        public static List<string> kursihijau11 = new List<string>();
        /// Form12
        /// 
        /// </summary>
       public static int angka12 = 0;
        public static List<int> kursimerah12 = new List<int>();
        public static List<string> kursihijau12 = new List<string>();
        /// Form13
        /// 
        /// </summary>
             public static int angka13 = 0;
        public static List<int> kursimerah13 = new List<int>();
        public static List<string> kursihijau13 = new List<string>();
        /// Form 14
        /// 
        /// </summary>
        public static int angka14 = 0;
        public static List<int> kursimerah14 = new List<int>();
        public static List<string> kursihijau14 = new List<string>();
        /// Form 15
        /// 
        /// </summary>
    public static int angka15 = 0;
        public static List<int> kursimerah15 = new List<int>();
        public static List<string> kursihijau15 = new List<string>();
        /// Form 16
        /// 
        /// </summary>
      public static int angka16 = 0;
        public static List<int> kursimerah16 = new List<int>();
        public static List<string> kursihijau16 = new List<string>();
        /// Form17
        /// 
        /// </summary>
        public static int angka17 = 0;
        public static List<int> kursimerah17 = new List<int>();
        public static List<string> kursihijau17 = new List<string>();
        /// Form 18
        /// 
        /// </summary>
        public static int angka18 = 0;
        public static List<int> kursimerah18 = new List<int>();
        public static List<string> kursihijau18 = new List<string>();
        /// Form19
        /// 
        /// </summary>
          public static int angka19 = 0;
        public static List<int> kursimerah19 = new List<int>();
        public static List<string> kursihijau19 = new List<string>();
        /// Form 20
        /// 
        /// </summary>
        public static int angka20 = 0;
        public static List<int> kursimerah20 = new List<int>();
        public static List<string> kursihijau20 = new List<string>();
        /// Form 21
        /// 
        /// </summary>
          public static int angka21 = 0;
        public static List<int> kursimerah21 = new List<int>();
        public static List<string> kursihijau21 = new List<string>();
        /// Form 22
        /// 
        /// </summary>
        public static int angka22 = 0;
        public static List<int> kursimerah22 = new List<int>();
        public static List<string> kursihijau22 = new List<string>();
        /// Form 23
        /// 
        /// </summary>
           public static int angka23 = 0;
        public static List<int> kursimerah23 = new List<int>();
        public static List<string> kursihijau23 = new List<string>();
        /// Form 25
        /// 
        /// </summary>
        public static int angka24 = 0;
        public static List<int> kursimerah24 = new List<int>();
        public static List<string> kursihijau24 = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }
        string[]text = File.ReadAllLines(@"C:\Users\USER\Downloads\List Movie.txt");//ngeload file movie list
        Button[,] buttonshowtime = new Button[8, 3]; //8 itu baris kebawah sedangkan 3 itu jam tayangnya
        int buttonagarkesamping = 190;
        int buttonagarkebawah = 130;
        int jam = 10; //jam awal tayang
      
        private void Form1_Load(object sender, EventArgs e)
        {
            string[] pisah = text[0].Split(',');//ngambil movie di dalam list
            PictureBox picture1 = new PictureBox(); //picture 1 is mario bross
            picture1.Image = Image.FromFile(@"C:\Users\USER\Downloads\Mario Bross.jpg"); //ngeload gambar
            picture1.SizeMode = PictureBoxSizeMode.StretchImage; //ngepasin ukuran gambar
            picture1.Location = new Point(80, 80); //lokasi koordinat gambar
            picture1.Size = new Size(100, 100); //ukuran panjang lebar gambar
            this.Controls.Add(picture1); //nambahin gambar tersebut ke form
            Label label1 = new Label();//bikin label
            label1.Location = new Point(90, 180);//lokasi label
            label1.Text = pisah[0];//text label tersebut diambil dari text file 
            label1.Font = new Font("Microsoft YaHei", 10);//font label tersebut
            this.Controls.Add(label1);//nambahin label ke form
            // dari line 25-35 buat 1 movie (mario bross)
            PictureBox picture2 = new PictureBox(); //picture 2 is Wakanda
            picture2.Image = Image.FromFile(@"C:\Users\USER\Downloads\Wakanda.jpg");
            picture2.SizeMode = PictureBoxSizeMode.StretchImage;
            picture2.Location = new Point(80, 210);
            picture2.Size = new Size(100, 100);
            this.Controls.Add(picture2);
            Label label2 = new Label();
            label2.Location = new Point(90, 310);
            label2.Text = pisah[1];
            label2.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label2);
            // dari line 37 - 47 buat wakanda forever
            PictureBox picture3 = new PictureBox(); //picture 3 is Ant Man
            picture3.Image = Image.FromFile(@"C:\Users\USER\Downloads\Ant Man.jpg");
            picture3.SizeMode = PictureBoxSizeMode.StretchImage;
            picture3.Location = new Point(80, 340);
            picture3.Size = new Size(100, 100);
            this.Controls.Add(picture3);
            Label label3 = new Label();
            label3.Location = new Point(90, 440);
            label3.Text = pisah[2];
            label3.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label3);
            // dari line 49 - 59 buat Ant Man
            PictureBox picture4 = new PictureBox(); //picture 4 is Dilan
            picture4.Image = Image.FromFile(@"C:\Users\USER\Downloads\Dilan.jpg");
            picture4.SizeMode = PictureBoxSizeMode.StretchImage;
            picture4.Location = new Point(80, 470);
            picture4.Size = new Size(100, 100);
            this.Controls.Add(picture4);
            Label label4 = new Label();
            label4.Location = new Point(90, 570);
            label4.Text = pisah[3];
            label4.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label4);
            // dari line 61-71 buat Dilan 1990
            PictureBox picture5 = new PictureBox(); //picture 5 is End Game
            picture5.Image = Image.FromFile(@"C:\Users\USER\Downloads\End Game.jpg");
            picture5.SizeMode = PictureBoxSizeMode.StretchImage;
            picture5.Location = new Point(80, 600);
            picture5.Size = new Size(100, 100);
            this.Controls.Add(picture5);
            Label label5 = new Label();
            label5.Location = new Point(90, 700);
            label5.Text = pisah[4];
            label5.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label5);
            //dari line 77-87 buat end game
            PictureBox picture6 = new PictureBox(); //picture 6 is Top Gun
            picture6.Image = Image.FromFile(@"C:\Users\USER\Downloads\Top Gun.jpg");
            picture6.SizeMode = PictureBoxSizeMode.StretchImage;
            picture6.Location = new Point(500, 80);
            picture6.Size = new Size(100, 100);
            this.Controls.Add(picture6);
            Label label6 = new Label();
            label6.Location = new Point(510, 180);
            label6.Text = pisah[5];
            label6.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label6);
            //dari line 89-99 buat top gun
            PictureBox picture7 = new PictureBox(); //picture 7 is Black Adam
            picture7.Image = Image.FromFile(@"C:\Users\USER\Downloads\Black Adam.jpg");
            picture7.SizeMode = PictureBoxSizeMode.StretchImage;
            picture7.Location = new Point(500, 210);
            picture7.Size = new Size(100, 100);
            this.Controls.Add(picture7);
            Label label7 = new Label();
            label7.Location = new Point(510, 310);
            label7.Text = pisah[6];
            label7.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label7);
            //dari line 101-111 buat black adam
            PictureBox picture8 = new PictureBox(); //picture 8 is Avatar
            picture8.Image = Image.FromFile(@"C:\Users\USER\Downloads\Avatar.jpg");
            picture8.SizeMode = PictureBoxSizeMode.StretchImage;
            picture8.Location = new Point(500, 340);
            picture8.Size = new Size(100, 100);
            this.Controls.Add(picture8);
            Label label8 = new Label();
            label8.Location = new Point(510, 440);
            label8.Text = pisah[7];
            label8.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label8);
            // dari line 113-123 buat avatar
            //bikin button by code
            for (int i = 0; i<8;i++) // buat kebawah fornya, ini fornya < 8 karena filmya ada 8
            {
                // i=0 mario bross
                // i=1 Wakanda
                // i=2 Ant Man
                // i=3 Dilan
                // i=4 End Game
                // i=5 Top Gun
                // i=6 Black Adam
                // i=7 Avatar
                for (int j=0; j<3;j++)//buat kesamping fornya, ini fornya <3 karena jam tayang filmnya ada 3 kali
                {
                    buttonshowtime[i, j] = new Button();
                    buttonshowtime[i, j].Location = new Point(buttonagarkesamping, buttonagarkebawah);
                    buttonshowtime[i, j].Text = jam.ToString ()+ ": 00";
                    buttonshowtime[i, j].Tag = i +","+ j;
                    buttonshowtime[i, j].Click += button_click;
                    this.Controls.Add(buttonshowtime[i, j]);
                    jam += 3; //jarak waktu showtimenya
                    buttonagarkesamping += 100; //antar showtime jaraknya 100
                }
                if (i < 4) //ketika i nya kurang dari 4 sistemnya button muncul kebawah
                {
                    buttonagarkesamping = 190;
                    buttonagarkebawah += 130; //spase antara button antar movie
                    jam = 10; //jam awal
                }
                if(i==4)//ketika i nya sudah = 4 buttonnya dipindah keatas
                {
                    buttonagarkesamping = 610;
                    buttonagarkebawah = 130; //posisinya ke atas
                    jam = 10;
                }
                if (i > 4)//button setelah posisi di atas
                {
                    buttonagarkesamping = 610;
                    buttonagarkebawah += 130;
                    jam = 10;
                }
            }
          //bikin event code
         
        }
        private void button_click (object sender, EventArgs e)
        {
            var buttonclick = sender as Button; //button yang diklik user
            string [] pemisahtagpadabuttonshowtime = buttonclick.Tag.ToString().Split (',');
            if (pemisahtagpadabuttonshowtime[0]=="0" && pemisahtagpadabuttonshowtime[1]=="0") //pemisahtagpadabuttonshowtime[0] sebelah kiri samping koma
            {
                Form2 form2 = new Form2();
                form2.Dock = DockStyle.Fill;
                form2.TopLevel = false;
                this.panel_container.Controls.Add(form2);
                form2.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "0" && pemisahtagpadabuttonshowtime[1] == "1")
            {
                Form3 form3 = new Form3();
                form3.Dock = DockStyle.Fill;
                form3.TopLevel = false;
                this.panel_container.Controls.Add(form3);
                form3.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "0" && pemisahtagpadabuttonshowtime[1] == "2")
            {
                Form4 form4 = new Form4();
                form4.Dock = DockStyle.Fill;
                form4.TopLevel = false;
                this.panel_container.Controls.Add(form4);
                form4.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "1" && pemisahtagpadabuttonshowtime[1] == "0")
            {
                Form5 form5 = new Form5();
                form5.Dock = DockStyle.Fill;
                form5.TopLevel = false;
                this.panel_container.Controls.Add(form5);
                form5.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "1" && pemisahtagpadabuttonshowtime[1] == "1")
            {
                Form6 form6 = new Form6();
                form6.Dock = DockStyle.Fill;
                form6.TopLevel = false;
                this.panel_container.Controls.Add(form6);
                form6.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "1" && pemisahtagpadabuttonshowtime[1] == "2")
            {
                Form7 form7 = new Form7();
                form7.Dock = DockStyle.Fill;
                form7.TopLevel = false;
                this.panel_container.Controls.Add(form7);
                form7.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "2" && pemisahtagpadabuttonshowtime[1] == "0")
            {
                Form8 form8 = new Form8();
                form8.Dock = DockStyle.Fill;
                form8.TopLevel = false;
                this.panel_container.Controls.Add(form8);
                form8.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "2" && pemisahtagpadabuttonshowtime[1] == "1")
            {
                Form9 form9 = new Form9();
                form9.Dock = DockStyle.Fill;
                form9.TopLevel = false;
                this.panel_container.Controls.Add(form9);
                form9.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "2" && pemisahtagpadabuttonshowtime[1] == "2")
            {
                Form10 form10 = new Form10();
                form10.Dock = DockStyle.Fill;
                form10.TopLevel = false;
                this.panel_container.Controls.Add(form10);
                form10.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "3" && pemisahtagpadabuttonshowtime[1] == "0")
            {
                Form11 form11 = new Form11();
                form11.Dock = DockStyle.Fill;
                form11.TopLevel = false;
                this.panel_container.Controls.Add(form11);
                form11.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "3" && pemisahtagpadabuttonshowtime[1] == "1")
            {
                Form12 form12 = new Form12();
                form12.Dock = DockStyle.Fill;
                form12.TopLevel = false;
                this.panel_container.Controls.Add(form12);
                form12.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "3" && pemisahtagpadabuttonshowtime[1] == "2")
            {
                Form13 form13 = new Form13();
                form13.Dock = DockStyle.Fill;
                form13.TopLevel = false;
                this.panel_container.Controls.Add(form13);
                form13.Show();
            }
            ////////////////////////////////////////////////////////////////
            if (pemisahtagpadabuttonshowtime[0] == "4" && pemisahtagpadabuttonshowtime[1] == "0")
            {
                Form14 form14 = new Form14();
                form14.Dock = DockStyle.Fill;
                form14.TopLevel = false;
                this.panel_container.Controls.Add(form14);
                form14.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "4" && pemisahtagpadabuttonshowtime[1] == "1")
            {
                Form15 form15 = new Form15();
                form15.Dock = DockStyle.Fill;
                form15.TopLevel = false;
                this.panel_container.Controls.Add(form15);
                form15.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "4" && pemisahtagpadabuttonshowtime[1] == "2")
            {
                Form16 form16 = new Form16();
                form16.Dock = DockStyle.Fill;
                form16.TopLevel = false;
                this.panel_container.Controls.Add(form16);
                form16.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "5" && pemisahtagpadabuttonshowtime[1] == "0")
            {
                Form17 form17 = new Form17();
                form17.Dock = DockStyle.Fill;
                form17.TopLevel = false;
                this.panel_container.Controls.Add(form17);
                form17.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "5" && pemisahtagpadabuttonshowtime[1] == "1")
            {
                Form18 form18 = new Form18();
                form18.Dock = DockStyle.Fill;
                form18.TopLevel = false;
                this.panel_container.Controls.Add(form18);
                form18.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "5" && pemisahtagpadabuttonshowtime[1] == "2")
            {
                Form19 form19 = new Form19();
                form19.Dock = DockStyle.Fill;
                form19.TopLevel = false;
                this.panel_container.Controls.Add(form19);
                form19.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "6" && pemisahtagpadabuttonshowtime[1] == "0")
            {
                Form20 form20 = new Form20();
                form20.Dock = DockStyle.Fill;
                form20.TopLevel = false;
                this.panel_container.Controls.Add(form20);
                form20.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "6" && pemisahtagpadabuttonshowtime[1] == "1")
            {
                Form21 form21 = new Form21();
                form21.Dock = DockStyle.Fill;
                form21.TopLevel = false;
                this.panel_container.Controls.Add(form21);
                form21.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "6" && pemisahtagpadabuttonshowtime[1] == "2")
            {
                Form22 form22 = new Form22();
                form22.Dock = DockStyle.Fill;
                form22.TopLevel = false;
                this.panel_container.Controls.Add(form22);
                form22.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "7" && pemisahtagpadabuttonshowtime[1] == "0")
            {
                Form23 form23 = new Form23();
                form23.Dock = DockStyle.Fill;
                form23.TopLevel = false;
                this.panel_container.Controls.Add(form23);
                form23.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "7" && pemisahtagpadabuttonshowtime[1] == "1")
            {
                Form24 form24 = new Form24();
                form24.Dock = DockStyle.Fill;
                form24.TopLevel = false;
                this.panel_container.Controls.Add(form24);
                form24.Show();
            }
            if (pemisahtagpadabuttonshowtime[0] == "7" && pemisahtagpadabuttonshowtime[1] == "2")
            {
                Form25 form25 = new Form25();
                form25.Dock = DockStyle.Fill;
                form25.TopLevel = false;
                this.panel_container.Controls.Add(form25);
                form25.Show();
            }
        }

        private void panel_container_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
