﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel_match = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBox_playerdata = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBox_playerdata,
            this.toolStripButton1,
            this.toolStripLabel_match});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel_match
            // 
            this.toolStripLabel_match.Name = "toolStripLabel_match";
            this.toolStripLabel_match.Size = new System.Drawing.Size(106, 22);
            this.toolStripLabel_match.Text = "Show Match Detail";
            this.toolStripLabel_match.Click += new System.EventHandler(this.toolStripLabel_match_Click);
            // 
            // toolStripTextBox_playerdata
            // 
            this.toolStripTextBox_playerdata.Name = "toolStripTextBox_playerdata";
            this.toolStripTextBox_playerdata.Size = new System.Drawing.Size(66, 22);
            this.toolStripTextBox_playerdata.Text = "Player Data";
            this.toolStripTextBox_playerdata.Click += new System.EventHandler(this.toolStripTextBox_playerdata_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(6, 25);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.toolStrip1);
            this.IsMdiContainer = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel_match;
        private System.Windows.Forms.ToolStripLabel toolStripTextBox_playerdata;
        private System.Windows.Forms.ToolStripSeparator toolStripButton1;
    }
}

