﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        string Query = "";
        string connectionString = "server=localhost;uid=root;pwd=root;database=premier_league";
        MySqlConnection Connection;
        MySqlCommand Command;
        MySqlDataAdapter DataAdapter;
        DataTable namateam = new DataTable();
        DataTable namapemain= new DataTable();
        DataTable infopemain= new DataTable();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            Query = "select team_name from premier_league.team;";
            Connection = new MySqlConnection(connectionString);
            Command= new MySqlCommand(Query,Connection);
            DataAdapter= new MySqlDataAdapter(Command);
            DataAdapter.Fill(namateam);

            comboBox_team.DataSource= namateam;
            comboBox_team.DisplayMember = "team_name";
        }

        private void comboBox_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            namapemain = new DataTable();
            string selectedteam = comboBox_team.Text;
            Query = $"SELECT p.player_name as'p' from player p,premier_league.team t where p.team_id=t.team_id and t.team_name='{selectedteam}' ;";
            Connection = new MySqlConnection(connectionString);
            Command = new MySqlCommand(Query, Connection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(namapemain);

            comboBox_player.DataSource= namapemain;
            comboBox_player.DisplayMember = "p";

        }

        private void comboBox_player_SelectedIndexChanged(object sender, EventArgs e)
        {
            infopemain= new DataTable();
            Query = $"select p.player_name,t.team_name,p.playing_pos as'position',n.nation ,p.team_number from player p,nationality n, team t where p.team_id=t.team_id and p.player_name='{comboBox_player.Text}' and t.team_name ='{comboBox_team.Text}' and n.nationality_id=p.nationality_id;";
            Connection = new MySqlConnection(connectionString);
            Command = new MySqlCommand(Query, Connection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(infopemain);

            labelname.Text = infopemain.Rows[0][0].ToString();
            labelteam.Text = infopemain.Rows[0][1].ToString();
            labelposition.Text = infopemain.Rows[0][2].ToString();
            labelnation.Text = infopemain.Rows[0][3].ToString();
            label_squadnum.Text= infopemain.Rows[0][4].ToString();
            infopemain = new DataTable();
            Query = $"SELECT player_id FROM player Where player_name='{comboBox_player.Text}';";
            Connection = new MySqlConnection(connectionString);
            Command = new MySqlCommand(Query, Connection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(infopemain);
            string pemainid= infopemain.Rows[0][0].ToString();

            infopemain = new DataTable();
            Query = $"select d.type from dmatch d where d.player_id='{pemainid}';";
            Connection = new MySqlConnection(connectionString);
            Command = new MySqlCommand(Query, Connection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(infopemain);

            int red=0, 
            yellow=0, 
            goal=0,
            penalty=0;
            foreach (DataRow row in infopemain.Rows)
            {
                foreach (var item in row.ItemArray)
                {
                    switch (item.ToString())
                    {
                        case "CY":
                            yellow++;
                            break;
                        case "CR":
                            red++;
                            break;
                        case "GO":
                            goal++;
                            break;
                        case "PM":
                            penalty++;
                            break;
                    }
                }
            }
            labelyellow.Text = yellow.ToString();
            labelred.Text=red.ToString();
            labelgoal.Text=goal.ToString();
            labelmiss.Text=penalty.ToString();
        }
    }
}
