﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        Form2 frm2;
        Form3 frm3;
        public Form1()
        {
            InitializeComponent();
        }
        private void toolStripLabel_match_Click(object sender, EventArgs e)
        {
            frm3 = new Form3();
            frm3.MdiParent= this;
            frm3.Dock = DockStyle.Fill;
            frm3.FormBorderStyle = FormBorderStyle.None;
            frm3.ControlBox = false;
            frm3.TopLevel = false;
            frm3.Show();
        }

        private void toolStripTextBox_playerdata_Click(object sender, EventArgs e)
        {
            frm2= new Form2();
            frm2.MdiParent= this;
            frm2.Dock = DockStyle.Fill;
            frm2.FormBorderStyle = FormBorderStyle.None;
            frm2.ControlBox = false;
            frm2.Show();
        }
    }
}
