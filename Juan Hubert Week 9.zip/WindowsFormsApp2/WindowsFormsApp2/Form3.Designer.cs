﻿namespace WindowsFormsApp2
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox_team = new System.Windows.Forms.ComboBox();
            this.comboBox_tanggal = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label_home = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label_away = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox_team
            // 
            this.comboBox_team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_team.FormattingEnabled = true;
            this.comboBox_team.Location = new System.Drawing.Point(12, 12);
            this.comboBox_team.Name = "comboBox_team";
            this.comboBox_team.Size = new System.Drawing.Size(121, 21);
            this.comboBox_team.TabIndex = 1;
            this.comboBox_team.SelectedIndexChanged += new System.EventHandler(this.comboBox_team_SelectedIndexChanged);
            // 
            // comboBox_tanggal
            // 
            this.comboBox_tanggal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_tanggal.FormattingEnabled = true;
            this.comboBox_tanggal.Location = new System.Drawing.Point(159, 12);
            this.comboBox_tanggal.Name = "comboBox_tanggal";
            this.comboBox_tanggal.Size = new System.Drawing.Size(121, 21);
            this.comboBox_tanggal.TabIndex = 2;
            this.comboBox_tanggal.SelectedIndexChanged += new System.EventHandler(this.comboBox_tanggal_SelectedIndexChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(10, 61);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(376, 173);
            this.dataGridView1.TabIndex = 3;
            // 
            // label_home
            // 
            this.label_home.AutoSize = true;
            this.label_home.Location = new System.Drawing.Point(154, 45);
            this.label_home.Name = "label_home";
            this.label_home.Size = new System.Drawing.Size(35, 13);
            this.label_home.TabIndex = 4;
            this.label_home.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(377, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "vs";
            // 
            // label_away
            // 
            this.label_away.AutoSize = true;
            this.label_away.Location = new System.Drawing.Point(554, 45);
            this.label_away.Name = "label_away";
            this.label_away.Size = new System.Drawing.Size(35, 13);
            this.label_away.TabIndex = 6;
            this.label_away.Text = "label3";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(392, 61);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(380, 173);
            this.dataGridView2.TabIndex = 7;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(183, 240);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(430, 173);
            this.dataGridView3.TabIndex = 8;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label_away);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_home);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.comboBox_tanggal);
            this.Controls.Add(this.comboBox_team);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_team;
        private System.Windows.Forms.ComboBox comboBox_tanggal;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label_home;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_away;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
    }
}