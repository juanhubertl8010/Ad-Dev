﻿namespace WindowsFormsApp2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_team = new System.Windows.Forms.ComboBox();
            this.comboBox_player = new System.Windows.Forms.ComboBox();
            this.labelmiss = new System.Windows.Forms.Label();
            this.labelgoal = new System.Windows.Forms.Label();
            this.labelred = new System.Windows.Forms.Label();
            this.labelyellow = new System.Windows.Forms.Label();
            this.labelnation = new System.Windows.Forms.Label();
            this.labelposition = new System.Windows.Forms.Label();
            this.labelteam = new System.Windows.Forms.Label();
            this.labelname = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_squadnum = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pilih Team";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Pilih Player";
            // 
            // comboBox_team
            // 
            this.comboBox_team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_team.FormattingEnabled = true;
            this.comboBox_team.Location = new System.Drawing.Point(152, 63);
            this.comboBox_team.Name = "comboBox_team";
            this.comboBox_team.Size = new System.Drawing.Size(121, 21);
            this.comboBox_team.TabIndex = 2;
            this.comboBox_team.SelectedIndexChanged += new System.EventHandler(this.comboBox_team_SelectedIndexChanged);
            // 
            // comboBox_player
            // 
            this.comboBox_player.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_player.FormattingEnabled = true;
            this.comboBox_player.Location = new System.Drawing.Point(152, 136);
            this.comboBox_player.Name = "comboBox_player";
            this.comboBox_player.Size = new System.Drawing.Size(121, 21);
            this.comboBox_player.TabIndex = 3;
            this.comboBox_player.SelectedIndexChanged += new System.EventHandler(this.comboBox_player_SelectedIndexChanged);
            // 
            // labelmiss
            // 
            this.labelmiss.AutoSize = true;
            this.labelmiss.Location = new System.Drawing.Point(469, 274);
            this.labelmiss.Name = "labelmiss";
            this.labelmiss.Size = new System.Drawing.Size(10, 13);
            this.labelmiss.TabIndex = 35;
            this.labelmiss.Text = "-";
            // 
            // labelgoal
            // 
            this.labelgoal.AutoSize = true;
            this.labelgoal.Location = new System.Drawing.Point(469, 249);
            this.labelgoal.Name = "labelgoal";
            this.labelgoal.Size = new System.Drawing.Size(10, 13);
            this.labelgoal.TabIndex = 34;
            this.labelgoal.Text = "-";
            // 
            // labelred
            // 
            this.labelred.AutoSize = true;
            this.labelred.Location = new System.Drawing.Point(469, 220);
            this.labelred.Name = "labelred";
            this.labelred.Size = new System.Drawing.Size(10, 13);
            this.labelred.TabIndex = 33;
            this.labelred.Text = "-";
            // 
            // labelyellow
            // 
            this.labelyellow.AutoSize = true;
            this.labelyellow.Location = new System.Drawing.Point(469, 192);
            this.labelyellow.Name = "labelyellow";
            this.labelyellow.Size = new System.Drawing.Size(10, 13);
            this.labelyellow.TabIndex = 32;
            this.labelyellow.Text = "-";
            // 
            // labelnation
            // 
            this.labelnation.AutoSize = true;
            this.labelnation.Location = new System.Drawing.Point(469, 145);
            this.labelnation.Name = "labelnation";
            this.labelnation.Size = new System.Drawing.Size(10, 13);
            this.labelnation.TabIndex = 31;
            this.labelnation.Text = "-";
            // 
            // labelposition
            // 
            this.labelposition.AutoSize = true;
            this.labelposition.Location = new System.Drawing.Point(469, 120);
            this.labelposition.Name = "labelposition";
            this.labelposition.Size = new System.Drawing.Size(10, 13);
            this.labelposition.TabIndex = 30;
            this.labelposition.Text = "-";
            // 
            // labelteam
            // 
            this.labelteam.AutoSize = true;
            this.labelteam.Location = new System.Drawing.Point(469, 91);
            this.labelteam.Name = "labelteam";
            this.labelteam.Size = new System.Drawing.Size(10, 13);
            this.labelteam.TabIndex = 29;
            this.labelteam.Text = "-";
            // 
            // labelname
            // 
            this.labelname.AutoSize = true;
            this.labelname.Location = new System.Drawing.Point(469, 63);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(10, 13);
            this.labelname.TabIndex = 28;
            this.labelname.Text = "-";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(368, 274);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 13);
            this.label10.TabIndex = 27;
            this.label10.Text = "Penalty Missed";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(368, 249);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 13);
            this.label9.TabIndex = 26;
            this.label9.Text = "Goal Scored";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(368, 220);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Red Card";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(368, 192);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "Yellow Card";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(368, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Nationality";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(368, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "Position";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(368, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Team";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(368, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Player Name";
            // 
            // label_squadnum
            // 
            this.label_squadnum.AutoSize = true;
            this.label_squadnum.Location = new System.Drawing.Point(469, 167);
            this.label_squadnum.Name = "label_squadnum";
            this.label_squadnum.Size = new System.Drawing.Size(10, 13);
            this.label_squadnum.TabIndex = 37;
            this.label_squadnum.Text = "-";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(368, 167);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 13);
            this.label12.TabIndex = 36;
            this.label12.Text = "Squad Number";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label_squadnum);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.labelmiss);
            this.Controls.Add(this.labelgoal);
            this.Controls.Add(this.labelred);
            this.Controls.Add(this.labelyellow);
            this.Controls.Add(this.labelnation);
            this.Controls.Add(this.labelposition);
            this.Controls.Add(this.labelteam);
            this.Controls.Add(this.labelname);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox_player);
            this.Controls.Add(this.comboBox_team);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox_team;
        private System.Windows.Forms.ComboBox comboBox_player;
        private System.Windows.Forms.Label labelmiss;
        private System.Windows.Forms.Label labelgoal;
        private System.Windows.Forms.Label labelred;
        private System.Windows.Forms.Label labelyellow;
        private System.Windows.Forms.Label labelnation;
        private System.Windows.Forms.Label labelposition;
        private System.Windows.Forms.Label labelteam;
        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_squadnum;
        private System.Windows.Forms.Label label12;
    }
}