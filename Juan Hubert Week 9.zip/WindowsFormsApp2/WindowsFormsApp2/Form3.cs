﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        string Query = "";
        string connectionString = "server=localhost;uid=root;pwd=root;database=premier_league";
        MySqlConnection Connection;
        MySqlCommand Command;
        MySqlDataAdapter DataAdapter;
        DataTable namateam = new DataTable();
        DataTable tanggal= new DataTable();
        DataTable player=new DataTable();
        public Form3()
        {
            InitializeComponent();
            
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            Query = "select team_name from premier_league.team;";
            Connection = new MySqlConnection(connectionString);
            Command = new MySqlCommand(Query, Connection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(namateam);
            comboBox_team.DataSource = namateam;
            comboBox_team.DisplayMember = "team_name";
        }

        private void comboBox_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            tanggal = new DataTable();
            Query=$"SELECT m.match_date as 'dates',m.match_id as'ID' FROM team t1,team t2, premier_league.match m\r\nWHERE (t1.team_name='{comboBox_team.Text}' or t2.team_name='{comboBox_team.Text}') \r\nAND t1.team_id=m.team_home AND t2.team_id=m.team_away;";
            Connection = new MySqlConnection(connectionString);
            Command = new MySqlCommand(Query, Connection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(tanggal);
            //dataGridView1.DataSource= tanggal;
            comboBox_tanggal.DataSource= tanggal;
            comboBox_tanggal.DisplayMember= "dates";
            comboBox_tanggal.ValueMember = "ID";
        }

        private void comboBox_tanggal_SelectedIndexChanged(object sender, EventArgs e)
        {
            namateam = new DataTable();
            Query = $"select t1.team_name as 't1', t2.team_name as 't2' \r\nfrom premier_league.match m, team t1, team t2 \r\nwhere m.team_home = t1.team_id and m.team_away = t2.team_id and m.match_id = '{comboBox_tanggal.SelectedValue.ToString()}';";
            Connection = new MySqlConnection(connectionString);
            Command = new MySqlCommand(Query, Connection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(namateam);
            label_home.Text = namateam.Rows[0][0].ToString();
            label_away.Text= namateam.Rows[0][1].ToString();

            player = new DataTable();
            Query = $"select t.team_name, p.player_name,p.playing_pos as'position'\r\nfrom player p, team t where p.team_id=t.team_id and t.team_name='{label_home.Text}';";
            Connection = new MySqlConnection(connectionString);
            Command = new MySqlCommand(Query, Connection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(player);
            dataGridView1.DataSource = player;

            player = new DataTable();
            Query = $"select t.team_name, p.player_name,p.playing_pos as'position'\r\nfrom player p, team t where p.team_id=t.team_id and t.team_name='{label_away.Text}';";
            Connection = new MySqlConnection(connectionString);
            Command = new MySqlCommand(Query, Connection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(player);
            dataGridView2.DataSource = player;

            player= new DataTable();
            Query= $"SELECT d.minute as'minute',t.team_name as'team name',p.player_name as'player name',if(d.type='CY','Yellow Card',if(d.type='CR','Red Card',if(d.type='GO','Goal',if(d.type='GP','Goal Penalty',if(d.type='GW','Own GOal','Penalty Miss'))))) as 'type'\r\nFROM dmatch d,team t,player p\r\nWHERE d.team_id=t.team_id AND d.player_id=p.player_id AND d.match_id='{comboBox_tanggal.SelectedValue.ToString()}';";
            Connection = new MySqlConnection(connectionString);
            Command = new MySqlCommand(Query, Connection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(player);
            dataGridView3.DataSource = player;
        }
    }
}
